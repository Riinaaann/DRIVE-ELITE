# Elite Drive — Next.js Source Export

This archive contains the complete Elite Drive source after migrating the frontend from Vite to Next.js.

## Included

- `frontend/` — Next.js App Router frontend and existing Elite Drive UI
- `api-server/` — Express API server
- `lib/api-client-react/` — generated React Query API client
- `lib/api-spec/` — OpenAPI source contract
- `lib/api-zod/` — generated validation/types
- `lib/db/` — Drizzle PostgreSQL schema
- workspace configuration and lockfile

## Run

1. Install pnpm dependencies from the repository root:
   `pnpm install`
2. Start the API server:
   `pnpm --filter @workspace/api-server run dev`
3. Start the Next.js frontend:
   `pnpm --filter @workspace/elite-drive run dev`

The frontend is configured to use the existing shared API paths and database-backed features.
